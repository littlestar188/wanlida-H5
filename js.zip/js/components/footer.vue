<template>
	<div class="state-pay">		
		<div id="pay">
			<a class="cart">立即支付</a>
		</div>
	</div>	
</template>